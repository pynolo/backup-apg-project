package it.giunti.apgautomation.server.jobs.rivixweb;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author paolo
 */
@Entity
@Table(name = "rivixweb", catalog = "abbonamenti_web", schema = "")
public class Rivixweb implements Serializable {
	private static final long serialVersionUID = -5194439277642541695L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Basic(optional = false)
    @Column(name = "codice_abbonato", nullable = false, length = 7)
    private String codiceAbbonato;
    @Column(name = "titolo", length = 6)
    private String titolo;
    @Basic(optional = false)
    @Column(name = "cognome_nome", nullable = false, length = 30)
    private String cognomeNome;
    @Column(name = "presso", length = 28)
    private String presso;
    @Column(name = "indirizzo", length = 36)
    private String indirizzo;
    @Column(name = "localita", length = 26)
    private String localita;
    @Column(name = "prov", length = 4)
    private String prov;
    @Column(name = "cap", length = 5)
    private String cap;
    @Column(name = "nazione", length = 21)
    private String nazione;
    @Column(name = "telefono", length = 30)
    private String telefono;
    @Column(name = "email", length = 60)
    private String email;
    @Column(name = "scadenza_anno", length = 4)
    private String scadenzaAnno;
    @Column(name = "scadenza_mese", length = 2)
    private String scadenzaMese;
    @Column(name = "scadenza_mese_descr", length = 9)
    private String scadenzaMeseDescr;
    @Column(name = "stato_abbonamento", length = 50)
    private String statoAbbonamento;
    @Column(name = "cod_suppl1", length = 1)
    private String codSuppl1;
    @Column(name = "cod_suppl2", length = 1)
    private String codSuppl2;
    @Column(name = "darinnovare", length = 2)
    private String darinnovare;
    @Column(name = "tipo_abbonamento", length = 2)
    private String tipoAbbonamento;
    @Column(name = "cod_promotore", length = 7)
    private String codPromotore;
    @Column(name = "vcampo", length = 18)
    private String vcampo;
    @Column(name = "importodapagare")
    private Double importodapagare;
    @Column(name = "copie")
    private Integer copie;
    @Column(name = "supplementi", length = 20)
    private String supplementi;
    @Column(name = "ultima_modifica")
    @Temporal(TemporalType.TIMESTAMP)
    private Date ultimaModifica;
    
    public Rivixweb() {
    }

    public Rivixweb(Integer id) {
        this.id = id;
    }

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Rivixweb)) {
            return false;
        }
        Rivixweb other = (Rivixweb) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Rivixweb[id=" + id + "] "+codiceAbbonato;
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCodiceAbbonato() {
		return codiceAbbonato;
	}

	public void setCodiceAbbonato(String codiceAbbonato) {
		this.codiceAbbonato = codiceAbbonato;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getCognomeNome() {
		return cognomeNome;
	}

	public void setCognomeNome(String cognomeNome) {
		this.cognomeNome = cognomeNome;
	}

	public String getPresso() {
		return presso;
	}

	public void setPresso(String presso) {
		this.presso = presso;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getLocalita() {
		return localita;
	}

	public void setLocalita(String localita) {
		this.localita = localita;
	}

	public String getProv() {
		return prov;
	}

	public void setProv(String prov) {
		this.prov = prov;
	}

	public String getCap() {
		return cap;
	}

	public void setCap(String cap) {
		this.cap = cap;
	}

	public String getNazione() {
		return nazione;
	}

	public void setNazione(String nazione) {
		this.nazione = nazione;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getScadenzaAnno() {
		return scadenzaAnno;
	}

	public void setScadenzaAnno(String scadenzaAnno) {
		this.scadenzaAnno = scadenzaAnno;
	}

	public String getScadenzaMese() {
		return scadenzaMese;
	}

	public void setScadenzaMese(String scadenzaMese) {
		this.scadenzaMese = scadenzaMese;
	}

	public String getScadenzaMeseDescr() {
		return scadenzaMeseDescr;
	}

	public void setScadenzaMeseDescr(String scadenzaMeseDescr) {
		this.scadenzaMeseDescr = scadenzaMeseDescr;
	}

	public String getStatoAbbonamento() {
		return statoAbbonamento;
	}

	public void setStatoAbbonamento(String statoAbbonamento) {
		this.statoAbbonamento = statoAbbonamento;
	}

	public String getCodSuppl1() {
		return codSuppl1;
	}

	public void setCodSuppl1(String codSuppl1) {
		this.codSuppl1 = codSuppl1;
	}

	public String getCodSuppl2() {
		return codSuppl2;
	}

	public void setCodSuppl2(String codSuppl2) {
		this.codSuppl2 = codSuppl2;
	}

	public String getDarinnovare() {
		return darinnovare;
	}

	public void setDarinnovare(String darinnovare) {
		this.darinnovare = darinnovare;
	}

	public String getTipoAbbonamento() {
		return tipoAbbonamento;
	}

	public void setTipoAbbonamento(String tipoAbbonamento) {
		this.tipoAbbonamento = tipoAbbonamento;
	}

	public String getCodPromotore() {
		return codPromotore;
	}

	public void setCodPromotore(String codPromotore) {
		this.codPromotore = codPromotore;
	}

	public String getVcampo() {
		return vcampo;
	}

	public void setVcampo(String vcampo) {
		this.vcampo = vcampo;
	}

	public Double getImportodapagare() {
		return importodapagare;
	}

	public void setImportodapagare(Double importodapagare) {
		this.importodapagare = importodapagare;
	}

	public Integer getCopie() {
		return copie;
	}

	public void setCopie(Integer copie) {
		this.copie = copie;
	}

	public String getSupplementi() {
		return supplementi;
	}

	public void setSupplementi(String supplementi) {
		this.supplementi = supplementi;
	}

	public Date getUltimaModifica() {
		return ultimaModifica;
	}

	public void setUltimaModifica(Date ultimaModifica) {
		this.ultimaModifica = ultimaModifica;
	}
    
}