package it.giunti.apgautomation.server.jobs.rivixweb;

import it.giunti.apg.server.persistence.BaseDao;
import it.giunti.apg.server.persistence.GenericDao;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.Session;

public class RivixwebDao implements BaseDao<Rivixweb> {

	@Override
	public void update(Session ses, Rivixweb instance) throws HibernateException {
		GenericDao.updateGeneric(ses, instance.getId(), instance);
	}

	@Override
	public Serializable save(Session ses, Rivixweb transientInstance)
			throws HibernateException {
		return GenericDao.saveGeneric(ses, transientInstance);
	}

	@Override
	public void delete(Session ses, Rivixweb instance)
			throws HibernateException {
		GenericDao.deleteGeneric(ses, instance.getId(), instance);
	}

}
