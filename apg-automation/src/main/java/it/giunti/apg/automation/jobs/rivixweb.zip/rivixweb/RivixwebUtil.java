package it.giunti.apgautomation.server.jobs.rivixweb;

import it.giunti.apg.server.business.FileFormatCommon;
import it.giunti.apg.server.business.IstanzeStatusBusiness;
import it.giunti.apg.server.persistence.PagamentiDao;
import it.giunti.apg.server.persistence.SessionFactory;
import it.giunti.apg.shared.AppConstants;
import it.giunti.apg.shared.BusinessException;
import it.giunti.apg.shared.model.Anagrafiche;
import it.giunti.apg.shared.model.IstanzeAbbonamenti;
import it.giunti.apg.shared.model.OpzioniIstanzeAbbonamenti;
import it.giunti.apg.shared.model.OpzioniListini;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.type.DateType;

public class RivixwebUtil {

	private static final SimpleDateFormat sdfAnno = new SimpleDateFormat("yyyy");
	private static final SimpleDateFormat sdfMese = new SimpleDateFormat("MM");
	private static final SimpleDateFormat sdfMeseDescr = new SimpleDateFormat("MMMMM", Locale.ITALY);
	//private String[] tipiPagabili = {"01","02","03","04","05","06","0E","2E","3E","FT"};
	//private Set<String> tipiPagabiliSet = new HashSet<String>(Arrays.asList(tipiPagabili));
	//private String[] tipiRegalo = {"PK","PW","PX", "PZ", "PY"};
	//private Set<String> tipiRegaloSet = new HashSet<String>(Arrays.asList(tipiRegalo));
	//private String[] tipiFatturati = {"18","0L","2L","3L","0M","PE","11","AZ","LB","DP","FN","09"};
	//private Set<String> tipiFatturatiSet = new HashSet<String>(Arrays.asList(tipiFatturati));
	
	//Per ciascun fascicolo finale memorizzo la data di scadenza per non 
	//ripetere la query ogni volta
	private Date today = new Date();
	private PagamentiDao pagamentiDao = new PagamentiDao();
	
	private static int LENGTH_TITOLO = 6;
	private static int LENGTH_RAGSOC= 29;//30
	private static int LENGTH_PRESSO = 28;
	private static int LENGTH_INDIRIZZO = 36;
	private static int LENGTH_LOCALITA = 26;
	private static int LENGTH_EMAIL = 60;
	
	/**
	 * Normalmente restituisce una sola riga che contiene i dati dell'abbonamento.
	 * Ma se l'abbonamento ha un donatore allora questa procedura deve fornire due oggetti Rivixweb,
	 * uno per l'abbonamento e uno per il pagante
	 * @param ses
	 * @param ia
	 * @return
	 */
	public List<Rivixweb> convertToRivixweb(Session ses, IstanzeAbbonamenti ia) throws BusinessException {
		List<Rivixweb> resultList = new ArrayList<Rivixweb>();
		Rivixweb riw = new Rivixweb();
		//Codice
		riw.setCodiceAbbonato(ia.getAbbonamento().getCodiceAbbonamento());
		//Titolo
		String titolo = ia.getAbbonato().getIndirizzoPrincipale().getTitolo();
		riw.setTitolo(titolo);
		//RagSoc
		String ragSoc = ia.getAbbonato().getIndirizzoPrincipale().getCognomeRagioneSociale();
		if (ia.getAbbonato().getIndirizzoPrincipale().getNome() != null) {
			if (ia.getAbbonato().getIndirizzoPrincipale().getNome().length() > 0) {
				ragSoc += " " + ia.getAbbonato().getIndirizzoPrincipale().getNome();
			}
		}
		riw.setCognomeNome(ragSoc);
		//presso
		String presso = ia.getAbbonato().getIndirizzoPrincipale().getPresso();
		riw.setPresso(presso);
		//indirizzo
		String indirizzo = ia.getAbbonato().getIndirizzoPrincipale().getIndirizzo();
		riw.setIndirizzo(indirizzo);
		//localita
		String localita = ia.getAbbonato().getIndirizzoPrincipale().getLocalita();
		riw.setLocalita(localita);
		//prov
		String idProv = ia.getAbbonato().getIndirizzoPrincipale().getProvincia();
		if (idProv == null) idProv = "";
		riw.setProv(idProv);
		//cap
		String cap = ia.getAbbonato().getIndirizzoPrincipale().getCap();
		if (cap == null) cap = "";
		riw.setCap(cap);
		//nazione
		riw.setNazione(ia.getAbbonato().getIndirizzoPrincipale().getNazione().getNomeNazione());
		if (riw.getNazione().equalsIgnoreCase("italia")) {
			riw.setNazione("");
		}
		//telefono
		String telefono = "";
		if (ia.getAbbonato().getTelCasa() != null) {
			telefono += ia.getAbbonato().getTelCasa()+" ";
		}
		if (ia.getAbbonato().getTelMobile() != null) {
			telefono += ia.getAbbonato().getTelMobile();
		}
		if (telefono.length() > 30) telefono = telefono.substring(0, 30);
		riw.setTelefono(telefono);
		//email
		String email = ia.getAbbonato().getEmailPrimaria();
		riw.setEmail(email);
		//calcolo data scadenza
		Date scadenza = ia.getFascicoloFine().getDataFine();
		if (scadenza == null) scadenza = ia.getFascicoloFine().getDataInizio();
		//scadenza anno
		riw.setScadenzaAnno(sdfAnno.format(scadenza));
		//scadenza mese
		riw.setScadenzaMese(sdfMese.format(scadenza));
		//scadenza mese descr
		riw.setScadenzaMeseDescr(sdfMeseDescr.format(scadenza));
		//stato abbonamento
		String statoAbb = makeStatoAbb(ses, ia);
		riw.setStatoAbbonamento(statoAbb);
		//cod opz1 (vuoto)
		//cod opz2 (vuoto)
		//da rinnovare
		String darinnovare = makeDaRinnovare(ses, ia);
		riw.setDarinnovare(darinnovare);
		//tipo abbonamento
		riw.setTipoAbbonamento(ia.getListino().getTipoAbbonamento().getCodice());
		//cod promotore
		if (ia.getPagante() != null) {
			String codPromotore = codZFromAnagrafica(ia.getPagante());
			Rivixweb riwZ = convertToRivixweb(ses, ia.getPagante());
			resultList.add(riwZ);
			riw.setCodPromotore(codPromotore);
		} else {
			riw.setCodPromotore("");
		}
		//vcampo
		String quintoCampo = FileFormatCommon.getQuintoCampo(
				ia.getAbbonamento().getCodiceAbbonamento(),
				ia.getAbbonamento().getPeriodico().getNumeroCc());
		quintoCampo = quintoCampo.substring(2, 16);//Il quinto campo e' ridotto per rimuovere le
		//le cifre dell'anno e dei codici di controllo
		riw.setVcampo(quintoCampo);
		//importo da pagare
		if (darinnovare.equals("SI")) {
			Double pagato = pagamentiDao.sumPagamentiByIstanzaAbbonamento(ses, ia.getId());
			Double listino = ia.getListino().getPrezzo();
			if (listino.doubleValue() > AppConstants.SOGLIA) {//eventuali opzioni
				for (OpzioniIstanzeAbbonamenti oia:ia.getOpzioniIstanzeAbbonamentiSet()) {
					boolean mandatory = false;
					for (OpzioniListini ol:ia.getListino().getOpzioniListiniSet()) {
						if (oia.getOpzione().getId() == ol.getOpzione().getId()) mandatory = true;
					}
					if (!mandatory) listino += oia.getOpzione().getPrezzo();
				}
			}
			listino = listino * ia.getCopie();
			Double dapagare = listino-pagato;
			if (dapagare > AppConstants.SOGLIA) {
				riw.setImportodapagare(dapagare);
			} else {
				riw.setImportodapagare(0D);
			}
		} else {
			riw.setImportodapagare(0D);
		}
		//copie
		riw.setCopie(ia.getCopie());
		//ultima modifica
		riw.setUltimaModifica(today);
		//opzioni
		String opzioni = "";
		if (ia.getOpzioniIstanzeAbbonamentiSet() != null) {
			for (OpzioniIstanzeAbbonamenti opz:ia.getOpzioniIstanzeAbbonamentiSet()) {
				if (opzioni.length() > 0) opzioni += ",";
				opzioni += opz.getOpzione().getCodiceInterno();
			}
		}
		riw.setSupplementi(opzioni);
		
		trimRivixwebStrings(riw);
		
		resultList.add(riw);
		return resultList;
	}
	
	@SuppressWarnings("unchecked")
	public List<IstanzeAbbonamenti> findModifiedInstances(Date startDt, int offset, int pageSize) throws BusinessException {
		List<IstanzeAbbonamenti> result = null;
		Session ses = SessionFactory.getSession();
		try {
			String queryString = "from IstanzeAbbonamenti ia where " +
					"(ia.dataModifica >= :dt1 or ia.dataCreazione >= :dt2) and " +
					"ia.ultimaDellaSerie = :b1 " +
					"order by ia.id asc ";
			Query q = ses.createQuery(queryString);
			q.setParameter("dt1", startDt, DateType.INSTANCE);
			q.setParameter("dt2", startDt, DateType.INSTANCE);
			q.setParameter("b1", Boolean.TRUE);
			q.setFirstResult(offset);
			q.setMaxResults(pageSize);
			result = (List<IstanzeAbbonamenti>) q.list();
		} catch (HibernateException e) {
			throw new BusinessException(e.getMessage(), e);
		} finally {
			ses.close();
		}
		return result;
	}
	
	private String codZFromAnagrafica(Anagrafiche anag) {
		String codCli = anag.getUid();
		if (codCli.length() > 6) codCli = codCli.substring(codCli.length()-6);
		String result = codCli;//"Z"+codCli;
		return result;
	}
	
	public Rivixweb convertToRivixweb(Session ses, Anagrafiche anag) {
		Rivixweb riw = new Rivixweb();
		//Codice
		String codCli = codZFromAnagrafica(anag);
		riw.setCodiceAbbonato(codCli);
		//Titolo
		riw.setTitolo(anag.getIndirizzoPrincipale().getTitolo());
		//RagSoc
		String ragSoc = anag.getIndirizzoPrincipale().getCognomeRagioneSociale();
		if (anag.getIndirizzoPrincipale().getNome() != null) {
			if (anag.getIndirizzoPrincipale().getNome().length() > 0) {
				ragSoc += " " + anag.getIndirizzoPrincipale().getNome();
			}
		}
		riw.setCognomeNome(ragSoc);
		//presso
		riw.setPresso(anag.getIndirizzoPrincipale().getPresso());
		//indirizzo
		riw.setIndirizzo(anag.getIndirizzoPrincipale().getIndirizzo());
		//localita
		riw.setLocalita(anag.getIndirizzoPrincipale().getLocalita());
		//prov
		String idProv = anag.getIndirizzoPrincipale().getProvincia();
		if (idProv == null) idProv = "";
		riw.setProv(idProv);
		//cap
		String cap = anag.getIndirizzoPrincipale().getCap();
		if (cap == null) cap = "";
		riw.setCap(cap);
		//nazione
		riw.setNazione(anag.getIndirizzoPrincipale().getNazione().getNomeNazione());
		if (riw.getNazione().equalsIgnoreCase("italia")) {
			riw.setNazione("");
		}
		//telefono
		String telefono = "";
		if (anag.getTelCasa() != null) {
			telefono += anag.getTelCasa()+" ";
		}
		if (anag.getTelMobile() != null) {
			telefono += anag.getTelMobile();
		}
		if (telefono.length() > 30) telefono = telefono.substring(0, 30);
		riw.setTelefono(telefono);
		//email
		riw.setEmail(anag.getEmailPrimaria());
		//ultima modifica
		riw.setUltimaModifica(today);
		
		trimRivixwebStrings(riw);
		
		return riw;
	}
	
	private void trimRivixwebStrings(Rivixweb rivixweb) {
		//Titolo
		if (rivixweb.getTitolo() != null) {
			if (rivixweb.getTitolo().length() > LENGTH_TITOLO) {
				String trimmed = rivixweb.getTitolo().substring(0,LENGTH_TITOLO);
				rivixweb.setTitolo(trimmed);
			}
		}
		//RagSoc
		if (rivixweb.getCognomeNome() != null) {
			if (rivixweb.getCognomeNome().length() > LENGTH_RAGSOC) {
				String trimmed = rivixweb.getCognomeNome().substring(0,LENGTH_RAGSOC);
				rivixweb.setCognomeNome(trimmed);
			}
		}
		//presso
		if (rivixweb.getPresso() != null) {
			if (rivixweb.getPresso().length() > LENGTH_PRESSO) {
				String trimmed = rivixweb.getPresso().substring(0,LENGTH_PRESSO);
				rivixweb.setPresso(trimmed);
			}
		}
		//indirizzo
		if (rivixweb.getIndirizzo() != null) {
			if (rivixweb.getIndirizzo().length() > LENGTH_INDIRIZZO) {
				String trimmed = rivixweb.getIndirizzo().substring(0,LENGTH_INDIRIZZO);
				rivixweb.setIndirizzo(trimmed);
			}
		}
		//localita
		if (rivixweb.getLocalita() != null) {
			if (rivixweb.getLocalita().length() > LENGTH_LOCALITA) {
				String trimmed = rivixweb.getLocalita().substring(0,LENGTH_LOCALITA);
				rivixweb.setLocalita(trimmed);
			}
		}
		//email
		if (rivixweb.getEmail() != null) {
			if (rivixweb.getEmail().length() > LENGTH_EMAIL) {
				String trimmed = rivixweb.getEmail().substring(0,LENGTH_EMAIL);
				rivixweb.setEmail(trimmed);
			}
		}
	}
	
	private String makeStatoAbb(Session ses, IstanzeAbbonamenti ia) {
		Date scadenza = ia.getFascicoloFine().getDataInizio();
		String result = "Abbonamento ";
		if (IstanzeStatusBusiness.isOmaggio(ia)) {
			//Omaggio
			result +="omaggio ";
		} else {
			//Non omaggio
			if (IstanzeStatusBusiness.isTipoRegalo(ia)){
				result +="regalo ";
			}
		}
		//Status
		if (scadenza.after(today)) {
			//nel periodo attivo
			if (IstanzeStatusBusiness.isInRegola(ia)) {
				result += "attivo ";
			} else {
				result += "in attesa di pagamento ";
			}
		} else {
			//dopo la scadenza
			result += "scaduto da rinnovare ";
		}
		return result;
	}
	
	private String makeDaRinnovare(Session ses, IstanzeAbbonamenti ia) {
		String result = "";
		if (!IstanzeStatusBusiness.isFatturato(ia) &&
				!IstanzeStatusBusiness.isOmaggio(ia)) {
			result = "SI";
		} else {
			result = "NO";
		}
		return result;
	}
}
