package it.giunti.apgautomation.server.jobs.rivixweb;

import org.hibernate.Session;

public class SessionFactoryAbboWeb {

	public static Session getSession() {
		return HibernateSessionFactoryAbboWeb.getSession();
	}
	
//	public static void closeSession() {
//		HibernateSessionFactory.closeSession();
//	}

}