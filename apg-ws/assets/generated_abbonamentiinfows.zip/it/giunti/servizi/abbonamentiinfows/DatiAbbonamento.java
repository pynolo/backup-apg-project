
package it.giunti.servizi.abbonamentiinfows;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DatiAbbonamento complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DatiAbbonamento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codice" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String8Type"/>
 *         &lt;element name="idRivista" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String4Type" minOccurs="0"/>
 *         &lt;element name="cognomeNome" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String32Type"/>
 *         &lt;element name="presso" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String32Type"/>
 *         &lt;element name="indirizzo" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String64Type"/>
 *         &lt;element name="cap" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String8Type"/>
 *         &lt;element name="localita" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String32Type"/>
 *         &lt;element name="prov" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String4Type"/>
 *         &lt;element name="copie" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="buonoAcquisto" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="areaExtra" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="email" type="{http://servizi.giunti.it/abbonamentiInfoWs/}String64Type" minOccurs="0"/>
 *         &lt;element name="attivo" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ultimoAggiornamento" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DatiAbbonamento", propOrder = {
    "codice",
    "idRivista",
    "cognomeNome",
    "presso",
    "indirizzo",
    "cap",
    "localita",
    "prov",
    "copie",
    "buonoAcquisto",
    "areaExtra",
    "email",
    "attivo",
    "ultimoAggiornamento"
})
public class DatiAbbonamento {

    @XmlElement(required = true)
    protected String codice;
    protected String idRivista;
    @XmlElement(required = true)
    protected String cognomeNome;
    @XmlElement(required = true)
    protected String presso;
    @XmlElement(required = true)
    protected String indirizzo;
    @XmlElement(required = true)
    protected String cap;
    @XmlElement(required = true)
    protected String localita;
    @XmlElement(required = true)
    protected String prov;
    protected int copie;
    protected boolean buonoAcquisto;
    protected boolean areaExtra;
    protected String email;
    protected Boolean attivo;
    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar ultimoAggiornamento;

    /**
     * Gets the value of the codice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodice() {
        return codice;
    }

    /**
     * Sets the value of the codice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodice(String value) {
        this.codice = value;
    }

    /**
     * Gets the value of the idRivista property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdRivista() {
        return idRivista;
    }

    /**
     * Sets the value of the idRivista property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdRivista(String value) {
        this.idRivista = value;
    }

    /**
     * Gets the value of the cognomeNome property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCognomeNome() {
        return cognomeNome;
    }

    /**
     * Sets the value of the cognomeNome property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCognomeNome(String value) {
        this.cognomeNome = value;
    }

    /**
     * Gets the value of the presso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPresso() {
        return presso;
    }

    /**
     * Sets the value of the presso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPresso(String value) {
        this.presso = value;
    }

    /**
     * Gets the value of the indirizzo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndirizzo() {
        return indirizzo;
    }

    /**
     * Sets the value of the indirizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndirizzo(String value) {
        this.indirizzo = value;
    }

    /**
     * Gets the value of the cap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCap() {
        return cap;
    }

    /**
     * Sets the value of the cap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCap(String value) {
        this.cap = value;
    }

    /**
     * Gets the value of the localita property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalita() {
        return localita;
    }

    /**
     * Sets the value of the localita property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalita(String value) {
        this.localita = value;
    }

    /**
     * Gets the value of the prov property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProv() {
        return prov;
    }

    /**
     * Sets the value of the prov property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProv(String value) {
        this.prov = value;
    }

    /**
     * Gets the value of the copie property.
     * 
     */
    public int getCopie() {
        return copie;
    }

    /**
     * Sets the value of the copie property.
     * 
     */
    public void setCopie(int value) {
        this.copie = value;
    }

    /**
     * Gets the value of the buonoAcquisto property.
     * 
     */
    public boolean isBuonoAcquisto() {
        return buonoAcquisto;
    }

    /**
     * Sets the value of the buonoAcquisto property.
     * 
     */
    public void setBuonoAcquisto(boolean value) {
        this.buonoAcquisto = value;
    }

    /**
     * Gets the value of the areaExtra property.
     * 
     */
    public boolean isAreaExtra() {
        return areaExtra;
    }

    /**
     * Sets the value of the areaExtra property.
     * 
     */
    public void setAreaExtra(boolean value) {
        this.areaExtra = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the attivo property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAttivo() {
        return attivo;
    }

    /**
     * Sets the value of the attivo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAttivo(Boolean value) {
        this.attivo = value;
    }

    /**
     * Gets the value of the ultimoAggiornamento property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getUltimoAggiornamento() {
        return ultimoAggiornamento;
    }

    /**
     * Sets the value of the ultimoAggiornamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setUltimoAggiornamento(XMLGregorianCalendar value) {
        this.ultimoAggiornamento = value;
    }

}
