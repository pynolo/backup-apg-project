@javax.xml.bind.annotation.XmlSchema(namespace = "http://servizi.giunti.it/abbonamentiInfoWs/")
package it.giunti.servizi.abbonamentiinfows;
