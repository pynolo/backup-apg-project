@javax.xml.bind.annotation.XmlSchema(namespace = "http://applicazioni.giunti.it/apgws/giuntiscuolainfo")
package it.giunti.apg.server.giuntiscuolainfo;
