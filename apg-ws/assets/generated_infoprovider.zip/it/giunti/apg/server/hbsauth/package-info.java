@javax.xml.bind.annotation.XmlSchema(namespace = "http://applicazioni.giunti.it/apgws/hbsauth")
package it.giunti.apg.server.hbsauth;
