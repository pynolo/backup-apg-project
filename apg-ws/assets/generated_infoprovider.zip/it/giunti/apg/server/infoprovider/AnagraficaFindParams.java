
package it.giunti.apg.server.infoprovider;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codiceCliente" type="{http://applicazioni.giunti.it/apgws/infoprovider}String16Type" minOccurs="0"/>
 *         &lt;element name="codiceAbbonamento" type="{http://applicazioni.giunti.it/apgws/infoprovider}String16Type" minOccurs="0"/>
 *         &lt;element name="dataControllo" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "codiceCliente",
    "codiceAbbonamento",
    "dataControllo"
})
@XmlRootElement(name = "AnagraficaFindParams")
public class AnagraficaFindParams {

    protected String codiceCliente;
    protected String codiceAbbonamento;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataControllo;

    /**
     * Gets the value of the codiceCliente property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceCliente() {
        return codiceCliente;
    }

    /**
     * Sets the value of the codiceCliente property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceCliente(String value) {
        this.codiceCliente = value;
    }

    /**
     * Gets the value of the codiceAbbonamento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceAbbonamento() {
        return codiceAbbonamento;
    }

    /**
     * Sets the value of the codiceAbbonamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceAbbonamento(String value) {
        this.codiceAbbonamento = value;
    }

    /**
     * Gets the value of the dataControllo property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataControllo() {
        return dataControllo;
    }

    /**
     * Sets the value of the dataControllo property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataControllo(XMLGregorianCalendar value) {
        this.dataControllo = value;
    }

}
