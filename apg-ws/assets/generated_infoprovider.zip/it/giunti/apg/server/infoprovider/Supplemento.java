
package it.giunti.apg.server.infoprovider;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Supplemento complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Supplemento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codiceSupplemento" type="{http://applicazioni.giunti.it/apgws/infoprovider}String16Type"/>
 *         &lt;element name="nome" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type"/>
 *         &lt;element name="prezzo" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="dataInizio" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataFine" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="cartaceo" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="digitale" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Supplemento", propOrder = {
    "codiceSupplemento",
    "nome",
    "prezzo",
    "dataInizio",
    "dataFine",
    "cartaceo",
    "digitale"
})
public class Supplemento {

    @XmlElement(required = true)
    protected String codiceSupplemento;
    @XmlElement(required = true)
    protected String nome;
    protected Double prezzo;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataInizio;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataFine;
    protected boolean cartaceo;
    protected boolean digitale;

    /**
     * Gets the value of the codiceSupplemento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceSupplemento() {
        return codiceSupplemento;
    }

    /**
     * Sets the value of the codiceSupplemento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceSupplemento(String value) {
        this.codiceSupplemento = value;
    }

    /**
     * Gets the value of the nome property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNome() {
        return nome;
    }

    /**
     * Sets the value of the nome property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Gets the value of the prezzo property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrezzo() {
        return prezzo;
    }

    /**
     * Sets the value of the prezzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrezzo(Double value) {
        this.prezzo = value;
    }

    /**
     * Gets the value of the dataInizio property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataInizio() {
        return dataInizio;
    }

    /**
     * Sets the value of the dataInizio property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataInizio(XMLGregorianCalendar value) {
        this.dataInizio = value;
    }

    /**
     * Gets the value of the dataFine property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataFine() {
        return dataFine;
    }

    /**
     * Sets the value of the dataFine property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataFine(XMLGregorianCalendar value) {
        this.dataFine = value;
    }

    /**
     * Gets the value of the cartaceo property.
     * 
     */
    public boolean isCartaceo() {
        return cartaceo;
    }

    /**
     * Sets the value of the cartaceo property.
     * 
     */
    public void setCartaceo(boolean value) {
        this.cartaceo = value;
    }

    /**
     * Gets the value of the digitale property.
     * 
     */
    public boolean isDigitale() {
        return digitale;
    }

    /**
     * Sets the value of the digitale property.
     * 
     */
    public void setDigitale(boolean value) {
        this.digitale = value;
    }

}
