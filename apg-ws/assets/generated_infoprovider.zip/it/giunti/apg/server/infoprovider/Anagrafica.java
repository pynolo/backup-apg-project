
package it.giunti.apg.server.infoprovider;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Anagrafica complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Anagrafica">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codiceCliente" type="{http://applicazioni.giunti.it/apgws/infoprovider}String16Type"/>
 *         &lt;element name="cognomeRagioneSociale" type="{http://applicazioni.giunti.it/apgws/infoprovider}String32Type"/>
 *         &lt;element name="nome" type="{http://applicazioni.giunti.it/apgws/infoprovider}String32Type" minOccurs="0"/>
 *         &lt;element name="presso" type="{http://applicazioni.giunti.it/apgws/infoprovider}String32Type" minOccurs="0"/>
 *         &lt;element name="indirizzo" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type" minOccurs="0"/>
 *         &lt;element name="cap" type="{http://applicazioni.giunti.it/apgws/infoprovider}String8Type" minOccurs="0"/>
 *         &lt;element name="localita" type="{http://applicazioni.giunti.it/apgws/infoprovider}String32Type" minOccurs="0"/>
 *         &lt;element name="provincia" type="{http://applicazioni.giunti.it/apgws/infoprovider}String4Type" minOccurs="0"/>
 *         &lt;element name="email" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type" minOccurs="0"/>
 *         &lt;element name="nazione" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type" minOccurs="0"/>
 *         &lt;element name="credito" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Anagrafica", propOrder = {
    "codiceCliente",
    "cognomeRagioneSociale",
    "nome",
    "presso",
    "indirizzo",
    "cap",
    "localita",
    "provincia",
    "email",
    "nazione",
    "credito"
})
public class Anagrafica {

    @XmlElement(required = true)
    protected String codiceCliente;
    @XmlElement(required = true)
    protected String cognomeRagioneSociale;
    protected String nome;
    protected String presso;
    protected String indirizzo;
    protected String cap;
    protected String localita;
    protected String provincia;
    protected String email;
    protected String nazione;
    protected Double credito;

    /**
     * Gets the value of the codiceCliente property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceCliente() {
        return codiceCliente;
    }

    /**
     * Sets the value of the codiceCliente property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceCliente(String value) {
        this.codiceCliente = value;
    }

    /**
     * Gets the value of the cognomeRagioneSociale property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCognomeRagioneSociale() {
        return cognomeRagioneSociale;
    }

    /**
     * Sets the value of the cognomeRagioneSociale property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCognomeRagioneSociale(String value) {
        this.cognomeRagioneSociale = value;
    }

    /**
     * Gets the value of the nome property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNome() {
        return nome;
    }

    /**
     * Sets the value of the nome property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Gets the value of the presso property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPresso() {
        return presso;
    }

    /**
     * Sets the value of the presso property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPresso(String value) {
        this.presso = value;
    }

    /**
     * Gets the value of the indirizzo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndirizzo() {
        return indirizzo;
    }

    /**
     * Sets the value of the indirizzo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndirizzo(String value) {
        this.indirizzo = value;
    }

    /**
     * Gets the value of the cap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCap() {
        return cap;
    }

    /**
     * Sets the value of the cap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCap(String value) {
        this.cap = value;
    }

    /**
     * Gets the value of the localita property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalita() {
        return localita;
    }

    /**
     * Sets the value of the localita property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalita(String value) {
        this.localita = value;
    }

    /**
     * Gets the value of the provincia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * Sets the value of the provincia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvincia(String value) {
        this.provincia = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the nazione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNazione() {
        return nazione;
    }

    /**
     * Sets the value of the nazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNazione(String value) {
        this.nazione = value;
    }

    /**
     * Gets the value of the credito property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCredito() {
        return credito;
    }

    /**
     * Sets the value of the credito property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCredito(Double value) {
        this.credito = value;
    }

}
