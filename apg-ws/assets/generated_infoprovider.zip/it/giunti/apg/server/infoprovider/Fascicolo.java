
package it.giunti.apg.server.infoprovider;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Fascicolo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Fascicolo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numeroFascicolo" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type"/>
 *         &lt;element name="dataCopertina" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type" minOccurs="0"/>
 *         &lt;element name="dataNominale" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataNominaleFine" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataPubblicazione" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Fascicolo", propOrder = {
    "numeroFascicolo",
    "dataCopertina",
    "dataNominale",
    "dataNominaleFine",
    "dataPubblicazione"
})
public class Fascicolo {

    @XmlElement(required = true)
    protected String numeroFascicolo;
    protected String dataCopertina;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataNominale;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataNominaleFine;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataPubblicazione;

    /**
     * Gets the value of the numeroFascicolo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroFascicolo() {
        return numeroFascicolo;
    }

    /**
     * Sets the value of the numeroFascicolo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroFascicolo(String value) {
        this.numeroFascicolo = value;
    }

    /**
     * Gets the value of the dataCopertina property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataCopertina() {
        return dataCopertina;
    }

    /**
     * Sets the value of the dataCopertina property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataCopertina(String value) {
        this.dataCopertina = value;
    }

    /**
     * Gets the value of the dataNominale property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataNominale() {
        return dataNominale;
    }

    /**
     * Sets the value of the dataNominale property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataNominale(XMLGregorianCalendar value) {
        this.dataNominale = value;
    }

    /**
     * Gets the value of the dataNominaleFine property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataNominaleFine() {
        return dataNominaleFine;
    }

    /**
     * Sets the value of the dataNominaleFine property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataNominaleFine(XMLGregorianCalendar value) {
        this.dataNominaleFine = value;
    }

    /**
     * Gets the value of the dataPubblicazione property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataPubblicazione() {
        return dataPubblicazione;
    }

    /**
     * Sets the value of the dataPubblicazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataPubblicazione(XMLGregorianCalendar value) {
        this.dataPubblicazione = value;
    }

}
