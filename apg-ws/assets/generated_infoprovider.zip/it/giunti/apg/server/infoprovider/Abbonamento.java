
package it.giunti.apg.server.infoprovider;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Abbonamento complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Abbonamento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codiceAbbonamento" type="{http://applicazioni.giunti.it/apgws/infoprovider}String8Type"/>
 *         &lt;element name="periodicoLettera" type="{http://applicazioni.giunti.it/apgws/infoprovider}String4Type" minOccurs="0"/>
 *         &lt;element name="periodicoDescr" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type" minOccurs="0"/>
 *         &lt;element name="dataCreazioneAbbonamento" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="dataCreazioneIstanza" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="adesione" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type" minOccurs="0"/>
 *         &lt;element name="fascicoliTotali" type="{http://applicazioni.giunti.it/apgws/infoprovider}String4Type" minOccurs="0"/>
 *         &lt;element name="fascicoliSpediti" type="{http://applicazioni.giunti.it/apgws/infoprovider}String4Type" minOccurs="0"/>
 *         &lt;element name="copie" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="dataDisdetta" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="invioBloccato" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="cartaceo" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="digitale" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="tipoAbbonamentoCodice" type="{http://applicazioni.giunti.it/apgws/infoprovider}String4Type" minOccurs="0"/>
 *         &lt;element name="tipoAbbonamentoDescr" type="{http://applicazioni.giunti.it/apgws/infoprovider}String64Type" minOccurs="0"/>
 *         &lt;element name="tipoAbbonamentoImporto" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="pagato" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="totalePagato" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="inFatturazione" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="fatturaData" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="fatturaNumero" type="{http://applicazioni.giunti.it/apgws/infoprovider}String32Type" minOccurs="0"/>
 *         &lt;element name="fatturaImporto" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="dataModifica" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="fascicoloInizio" type="{http://applicazioni.giunti.it/apgws/infoprovider}Fascicolo" minOccurs="0"/>
 *         &lt;element name="fascicoloFine" type="{http://applicazioni.giunti.it/apgws/infoprovider}Fascicolo" minOccurs="0"/>
 *         &lt;element name="supplemento" type="{http://applicazioni.giunti.it/apgws/infoprovider}Supplemento" maxOccurs="256" minOccurs="0"/>
 *         &lt;element name="abbonato" type="{http://applicazioni.giunti.it/apgws/infoprovider}Anagrafica" minOccurs="0"/>
 *         &lt;element name="pagante" type="{http://applicazioni.giunti.it/apgws/infoprovider}Anagrafica" minOccurs="0"/>
 *         &lt;element name="promotore" type="{http://applicazioni.giunti.it/apgws/infoprovider}Anagrafica" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Abbonamento", propOrder = {
    "codiceAbbonamento",
    "periodicoLettera",
    "periodicoDescr",
    "dataCreazioneAbbonamento",
    "dataCreazioneIstanza",
    "adesione",
    "fascicoliTotali",
    "fascicoliSpediti",
    "copie",
    "dataDisdetta",
    "invioBloccato",
    "cartaceo",
    "digitale",
    "tipoAbbonamentoCodice",
    "tipoAbbonamentoDescr",
    "tipoAbbonamentoImporto",
    "pagato",
    "totalePagato",
    "inFatturazione",
    "fatturaData",
    "fatturaNumero",
    "fatturaImporto",
    "dataModifica",
    "fascicoloInizio",
    "fascicoloFine",
    "supplemento",
    "abbonato",
    "pagante",
    "promotore"
})
public class Abbonamento {

    @XmlElement(required = true)
    protected String codiceAbbonamento;
    protected String periodicoLettera;
    protected String periodicoDescr;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataCreazioneAbbonamento;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataCreazioneIstanza;
    protected String adesione;
    protected String fascicoliTotali;
    protected String fascicoliSpediti;
    protected Integer copie;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataDisdetta;
    protected Boolean invioBloccato;
    protected boolean cartaceo;
    protected boolean digitale;
    protected String tipoAbbonamentoCodice;
    protected String tipoAbbonamentoDescr;
    protected Double tipoAbbonamentoImporto;
    protected Boolean pagato;
    protected Double totalePagato;
    protected Boolean inFatturazione;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar fatturaData;
    protected String fatturaNumero;
    protected Double fatturaImporto;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dataModifica;
    protected Fascicolo fascicoloInizio;
    protected Fascicolo fascicoloFine;
    protected List<Supplemento> supplemento;
    protected Anagrafica abbonato;
    protected Anagrafica pagante;
    protected Anagrafica promotore;

    /**
     * Gets the value of the codiceAbbonamento property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceAbbonamento() {
        return codiceAbbonamento;
    }

    /**
     * Sets the value of the codiceAbbonamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceAbbonamento(String value) {
        this.codiceAbbonamento = value;
    }

    /**
     * Gets the value of the periodicoLettera property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicoLettera() {
        return periodicoLettera;
    }

    /**
     * Sets the value of the periodicoLettera property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicoLettera(String value) {
        this.periodicoLettera = value;
    }

    /**
     * Gets the value of the periodicoDescr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodicoDescr() {
        return periodicoDescr;
    }

    /**
     * Sets the value of the periodicoDescr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodicoDescr(String value) {
        this.periodicoDescr = value;
    }

    /**
     * Gets the value of the dataCreazioneAbbonamento property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataCreazioneAbbonamento() {
        return dataCreazioneAbbonamento;
    }

    /**
     * Sets the value of the dataCreazioneAbbonamento property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataCreazioneAbbonamento(XMLGregorianCalendar value) {
        this.dataCreazioneAbbonamento = value;
    }

    /**
     * Gets the value of the dataCreazioneIstanza property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataCreazioneIstanza() {
        return dataCreazioneIstanza;
    }

    /**
     * Sets the value of the dataCreazioneIstanza property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataCreazioneIstanza(XMLGregorianCalendar value) {
        this.dataCreazioneIstanza = value;
    }

    /**
     * Gets the value of the adesione property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdesione() {
        return adesione;
    }

    /**
     * Sets the value of the adesione property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdesione(String value) {
        this.adesione = value;
    }

    /**
     * Gets the value of the fascicoliTotali property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFascicoliTotali() {
        return fascicoliTotali;
    }

    /**
     * Sets the value of the fascicoliTotali property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFascicoliTotali(String value) {
        this.fascicoliTotali = value;
    }

    /**
     * Gets the value of the fascicoliSpediti property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFascicoliSpediti() {
        return fascicoliSpediti;
    }

    /**
     * Sets the value of the fascicoliSpediti property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFascicoliSpediti(String value) {
        this.fascicoliSpediti = value;
    }

    /**
     * Gets the value of the copie property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCopie() {
        return copie;
    }

    /**
     * Sets the value of the copie property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCopie(Integer value) {
        this.copie = value;
    }

    /**
     * Gets the value of the dataDisdetta property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataDisdetta() {
        return dataDisdetta;
    }

    /**
     * Sets the value of the dataDisdetta property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataDisdetta(XMLGregorianCalendar value) {
        this.dataDisdetta = value;
    }

    /**
     * Gets the value of the invioBloccato property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isInvioBloccato() {
        return invioBloccato;
    }

    /**
     * Sets the value of the invioBloccato property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setInvioBloccato(Boolean value) {
        this.invioBloccato = value;
    }

    /**
     * Gets the value of the cartaceo property.
     * 
     */
    public boolean isCartaceo() {
        return cartaceo;
    }

    /**
     * Sets the value of the cartaceo property.
     * 
     */
    public void setCartaceo(boolean value) {
        this.cartaceo = value;
    }

    /**
     * Gets the value of the digitale property.
     * 
     */
    public boolean isDigitale() {
        return digitale;
    }

    /**
     * Sets the value of the digitale property.
     * 
     */
    public void setDigitale(boolean value) {
        this.digitale = value;
    }

    /**
     * Gets the value of the tipoAbbonamentoCodice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoAbbonamentoCodice() {
        return tipoAbbonamentoCodice;
    }

    /**
     * Sets the value of the tipoAbbonamentoCodice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoAbbonamentoCodice(String value) {
        this.tipoAbbonamentoCodice = value;
    }

    /**
     * Gets the value of the tipoAbbonamentoDescr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoAbbonamentoDescr() {
        return tipoAbbonamentoDescr;
    }

    /**
     * Sets the value of the tipoAbbonamentoDescr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoAbbonamentoDescr(String value) {
        this.tipoAbbonamentoDescr = value;
    }

    /**
     * Gets the value of the tipoAbbonamentoImporto property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTipoAbbonamentoImporto() {
        return tipoAbbonamentoImporto;
    }

    /**
     * Sets the value of the tipoAbbonamentoImporto property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTipoAbbonamentoImporto(Double value) {
        this.tipoAbbonamentoImporto = value;
    }

    /**
     * Gets the value of the pagato property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPagato() {
        return pagato;
    }

    /**
     * Sets the value of the pagato property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPagato(Boolean value) {
        this.pagato = value;
    }

    /**
     * Gets the value of the totalePagato property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getTotalePagato() {
        return totalePagato;
    }

    /**
     * Sets the value of the totalePagato property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setTotalePagato(Double value) {
        this.totalePagato = value;
    }

    /**
     * Gets the value of the inFatturazione property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isInFatturazione() {
        return inFatturazione;
    }

    /**
     * Sets the value of the inFatturazione property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setInFatturazione(Boolean value) {
        this.inFatturazione = value;
    }

    /**
     * Gets the value of the fatturaData property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFatturaData() {
        return fatturaData;
    }

    /**
     * Sets the value of the fatturaData property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFatturaData(XMLGregorianCalendar value) {
        this.fatturaData = value;
    }

    /**
     * Gets the value of the fatturaNumero property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFatturaNumero() {
        return fatturaNumero;
    }

    /**
     * Sets the value of the fatturaNumero property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFatturaNumero(String value) {
        this.fatturaNumero = value;
    }

    /**
     * Gets the value of the fatturaImporto property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getFatturaImporto() {
        return fatturaImporto;
    }

    /**
     * Sets the value of the fatturaImporto property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setFatturaImporto(Double value) {
        this.fatturaImporto = value;
    }

    /**
     * Gets the value of the dataModifica property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDataModifica() {
        return dataModifica;
    }

    /**
     * Sets the value of the dataModifica property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDataModifica(XMLGregorianCalendar value) {
        this.dataModifica = value;
    }

    /**
     * Gets the value of the fascicoloInizio property.
     * 
     * @return
     *     possible object is
     *     {@link Fascicolo }
     *     
     */
    public Fascicolo getFascicoloInizio() {
        return fascicoloInizio;
    }

    /**
     * Sets the value of the fascicoloInizio property.
     * 
     * @param value
     *     allowed object is
     *     {@link Fascicolo }
     *     
     */
    public void setFascicoloInizio(Fascicolo value) {
        this.fascicoloInizio = value;
    }

    /**
     * Gets the value of the fascicoloFine property.
     * 
     * @return
     *     possible object is
     *     {@link Fascicolo }
     *     
     */
    public Fascicolo getFascicoloFine() {
        return fascicoloFine;
    }

    /**
     * Sets the value of the fascicoloFine property.
     * 
     * @param value
     *     allowed object is
     *     {@link Fascicolo }
     *     
     */
    public void setFascicoloFine(Fascicolo value) {
        this.fascicoloFine = value;
    }

    /**
     * Gets the value of the supplemento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the supplemento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSupplemento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Supplemento }
     * 
     * 
     */
    public List<Supplemento> getSupplemento() {
        if (supplemento == null) {
            supplemento = new ArrayList<Supplemento>();
        }
        return this.supplemento;
    }

    /**
     * Gets the value of the abbonato property.
     * 
     * @return
     *     possible object is
     *     {@link Anagrafica }
     *     
     */
    public Anagrafica getAbbonato() {
        return abbonato;
    }

    /**
     * Sets the value of the abbonato property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anagrafica }
     *     
     */
    public void setAbbonato(Anagrafica value) {
        this.abbonato = value;
    }

    /**
     * Gets the value of the pagante property.
     * 
     * @return
     *     possible object is
     *     {@link Anagrafica }
     *     
     */
    public Anagrafica getPagante() {
        return pagante;
    }

    /**
     * Sets the value of the pagante property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anagrafica }
     *     
     */
    public void setPagante(Anagrafica value) {
        this.pagante = value;
    }

    /**
     * Gets the value of the promotore property.
     * 
     * @return
     *     possible object is
     *     {@link Anagrafica }
     *     
     */
    public Anagrafica getPromotore() {
        return promotore;
    }

    /**
     * Sets the value of the promotore property.
     * 
     * @param value
     *     allowed object is
     *     {@link Anagrafica }
     *     
     */
    public void setPromotore(Anagrafica value) {
        this.promotore = value;
    }

}
