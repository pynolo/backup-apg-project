@javax.xml.bind.annotation.XmlSchema(namespace = "http://applicazioni.giunti.it/apgws/infoprovider")
package it.giunti.apg.server.infoprovider;
